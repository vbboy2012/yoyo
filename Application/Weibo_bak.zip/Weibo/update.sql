ALTER TABLE  `ocenter_weibo_cache` ADD INDEX (  `weibo_id` ),
ADD INDEX ( `groups` );