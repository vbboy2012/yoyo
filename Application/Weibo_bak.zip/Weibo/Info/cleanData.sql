DROP TABLE IF EXISTS `ocenter_weibo`;
DROP TABLE IF EXISTS `ocenter_weibo_comment`;
DROP TABLE IF EXISTS `ocenter_weibo_top`;
DROP TABLE IF EXISTS `ocenter_weibo_topic`;
